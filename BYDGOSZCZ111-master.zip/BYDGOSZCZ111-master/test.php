<?php
    $corobi = "zapierdala";
    echo "twoja stara " . $corobi;
    
    echo " jestem psychiczny bo lubie grac w fife"
?>